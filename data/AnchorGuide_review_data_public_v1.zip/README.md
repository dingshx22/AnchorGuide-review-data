# AnchorGuide review data

This archive contains the audited, derived case-level records used to check
the quality and runtime results reported for the manuscript:

*Hierarchy as Guidance, Not Commitment: AnchorGuide for Fixed-Vertex
Hypergraph Partitioning in VLSI Design Automation.*

The archive supports review of reported aggregates and selected reproducibility
checks. It is not a turnkey solver reproduction kit: benchmark netlists, graph
inputs, solver binaries, and full run-output trees are intentionally excluded.
Machine-local paths and full command strings are omitted. The public copy
redacts one retained local stage-root value in `E091/stage_audit.json`; this
does not change any result record or hash-checked numerical data.

## Contents

- `E091/`: single-seed paired case medians for the harmonized external-solver
  comparison and independent execution/timing audit summaries.
- `E115/`: five-seed paired quality and case-timing summaries, plus per-run
  quality/timing manifests with local paths omitted.
- `E116/`: per-case parameter quality/timing records and held-out sensitivity
  results.
- `E117/`: per-case stage medians and runtime-composition records.
- `E118/`: conditional add-back results and the two retained clock-consistency
  exceptions; these pilot timings are excluded from the main external speedups.
- `E197/` and `E198/`: sparse guide-only quality and separate matched timing
  records.
- `T194/` and `T195/`: fixed-induced bounds and dense package comparisons.
- `protocols.json`: compact configuration and binary-identity summaries.
- `source_index.json`: repository-relative source paths and source hashes.
- `package_manifest.json`: SHA-256 values for every packaged file.
- `verify_review_data.py`: offline integrity and headline-point checks.

## Verification

Run the following command from the extracted archive directory:

```text
python verify_review_data.py
```

The check uses only the Python standard library. It verifies package hashes,
case counts, selected pooled result points, and the explicit exclusion of
E118's anomalous internal timers from external-speed claims.

Quality changes use the estimator named in each study. E115 reports the mean
of five seed-wise pooled ratios; E091 is a separate seed-1 study. E197's
sparse guide quality and E198's guide timing are separate studies and must not
be combined into a net benefit or treated as a matched cost-benefit estimate.

The records establish the saved runs and output identities within their stated
scopes. They do not establish independent re-execution of the solver or
equivalence across binaries.
