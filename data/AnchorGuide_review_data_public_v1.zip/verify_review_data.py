"""Verify the extracted AnchorGuide review-data bundle without solver software."""
import csv
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def rows(name):
    with (ROOT / name).open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def close(actual, expected, tolerance=5e-5):
    assert math.isclose(actual, expected, rel_tol=0, abs_tol=tolerance), (actual, expected)


def main():
    manifest = json.loads((ROOT / "package_manifest.json").read_text(encoding="utf-8"))
    for rel, expected in manifest["files"].items():
        path = ROOT / rel
        assert path.is_file(), rel
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected["sha256"], rel

    stage_audit = json.loads((ROOT / "E091/stage_audit.json").read_text(encoding="utf-8"))
    assert stage_audit["stage_root"] == "[redacted-local-stage-root]"

    e091 = rows("E091/case_timing_summary.csv")
    assert len(e091) == 270
    e091_75 = [r for r in e091 if r["ratio_percent"] == "75"]
    close(sum(float(r["kahypar_reference_median_s"]) for r in e091_75) /
          sum(float(r["e070_single_median_s"]) for r in e091_75), 4.5699032444)

    q = rows("E115/case_level_quality.csv")
    t = rows("E115/case_timing.csv")
    assert len(q) == len(t) == 540
    for density, expected_quality, expected_time in [
        ("50", -1.0447883265, 4.9475025165),
        ("75", -0.3537037979, 4.7388280823),
    ]:
        quality_means, time_means = [], []
        for seed in range(1, 6):
            qr = [r for r in q if r["density"] == density and int(r["solver_seed"]) == seed]
            tr = [r for r in t if r["density"] == density and int(r["solver_seed"]) == seed]
            assert len(qr) == len(tr) == 54
            quality_means.append(100 * (sum(float(r["kahypar_km1"]) for r in qr) -
                                        sum(float(r["anchor_km1"]) for r in qr)) /
                                 sum(float(r["kahypar_km1"]) for r in qr))
            time_means.append(sum(float(r["kahypar_median_seconds"]) for r in tr) /
                              sum(float(r["anchor_median_seconds"]) for r in tr))
        close(sum(quality_means) / 5, expected_quality)
        close(sum(time_means) / 5, expected_time)
    run_manifest = rows("E115/timing_manifest.csv")
    expected_binaries = {
        "18cbd512cb83e696f50591dd190463ba489108b66cacdea0c08e9a7322aeb279",
        "52c9256a570f110adc9755b458f42354dd314f804ea0f7ddf50f1e756c28f634",
    }
    assert len(run_manifest) == 6480
    assert {r["binary_hash"] for r in run_manifest} == expected_binaries
    assert all(r["valid_output"] == "True" and r["cpu_core"] == "0" and
               r["thread_count"] == "1" for r in run_manifest)

    guide = rows("E197/guide_quality_cases.csv")
    guide_time = rows("E198/guide_timing_cases.csv")
    assert len(guide) == len(guide_time) == 54
    close(100 * (sum(float(r["V0"]) for r in guide) -
                 sum(float(r["V1"]) for r in guide)) /
          sum(float(r["V0"]) for r in guide), 5.8084)
    close(sum(float(r["V1_median_s"]) for r in guide_time) /
          sum(float(r["V0_median_s"]) for r in guide_time), 1.06247455595)

    e117 = rows("E117/stage_case_medians.csv")
    assert len(e117) == 324
    e118 = rows("E118/pilot_paired_cases.csv")
    assert len(e118) == 36
    anomalies = json.loads((ROOT / "E118/timing_consistency.json").read_text(encoding="utf-8"))
    assert anomalies["anomaly_count"] == 2 and anomalies["timing_consistency_pass"] is False
    protocols = json.loads((ROOT / "protocols.json").read_text(encoding="utf-8"))
    assert protocols["E118"]["binary_sha256"] not in expected_binaries
    print("PASS: package hashes, case counts, pooled result points, and E118 timing exclusions")


if __name__ == "__main__":
    main()
